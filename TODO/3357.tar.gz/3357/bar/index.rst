bar.rst
=======

.. toctree::

   bar1
   bar2
   bar3
