baz.rst
=======

baz-1
-----

baz-2
-----

baz-3
-----
