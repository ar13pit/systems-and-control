foo.rst
=======

foo-1
-----

foo-2
-----

foo-3
-----
