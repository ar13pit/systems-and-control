.. Test documentation master file, created by
   sphinx-quickstart on Thu Feb  2 15:03:30 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Test's documentation!
================================

.. toctree::
   :maxdepth: 2
   :numbered:
   :caption: Contents:

   foo
   bar/index
   baz



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
